
package runapplication;

import java.util.Scanner;

public class RunApplication {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input details
        System.out.println("Enter Vehicle Type:");
        String vehicleType = scanner.nextLine();

        System.out.println("Enter City:");
        String city = scanner.nextLine();

        System.out.println("Enter Total Number of Accidents:");
        int accidentTotal = scanner.nextInt();

        // Create an instance of RoadAccidentReport
        RoadAccidentReport report = new RoadAccidentReport(vehicleType, city, accidentTotal);

        // Print the accident report
        report.printAccidentReport();
    }
}

//References
//https://learn-eu-central-1-prod-fleet01-xythos.content.blackboardcdn.com/5f5880ccc4141/9585806?X-Blackboard-S3-Bucket=learn-eu-central-1-prod-fleet01-xythos&X-Blackboard-Expiration=1727697600000&X-Blackboard-Signature=FrQuzn3SoRVgClnHKaHSL5B%2BP0UzneFYTw%2FlOwKf4nY%3D&X-Blackboard-Client-Id=515070&X-Blackboard-S3-Region=eu-central-1&response-cache-control=private%2C%20max-age%3D21600&response-content-disposition=inline%3B%20filename%2A%3DUTF-8%27%27Chp12.pdf&response-content-type=application%2Fpdf&X-Amz-Security-Token=IQoJb3JpZ2luX2VjECcaDGV1LWNlbnRyYWwtMSJHMEUCIDZqf68ovm9YoP%2FWIs9W5p2EGEBnuZMLsKMwHewR9VeDAiEAhDTyQNoneZKsSDacPE9ujpWWHRthfP7IN4lcsCswBesqvgUIcBAEGgw2MzU1Njc5MjQxODMiDOCheVX4keAMQ3VxqCqbBfDIWHLKdLJerrXESppGrOB6VR5xRrgOpQVsMLgcBYUhdp66Yv1hoPOpJppbqRKgR6NxTSRrhJR397Wn0ObCpHlKe13sg4NVIpCWZUJzqrzJs7onuc2t3vwsdQ7ogIs8Kbq48jpgVJZMlnACw3Y01zRTFYbZMrDt%2FpOuLFGDadqtVju82Zewd9JFDj%2Ff1ZVACNAlTVAscg1BGLzfzA1wwmO8BEZUBJMFbqhnPGW%2Fj9G8V3D3GVITsrPXfJLK8gO6Th337gh%2FFKSmlvN%2BY7YInbvcBU2aW2S4W%2BIhjoYhf6pNwmo2j02ZBH7vpb4Mujq602UvyRP4Gwgft9fWETVgbjD4Spbghw8n3I%2FWeQyO3eCbllXB0JOFpL1QvIyOFCrPYJejwE8OLcmJK%2FY7O%2FI6koKooyLe9yTCxIk3NZrWbwmUpk%2BluNl4SWyZ94miDmaIf2iiRoC3uwFKg6BAjetWQWQhRC1hLhp1U3p0PHcmb5fZiQGjV9ROn3DhB%2BgtjYIXe3HqdUBQ4bib87FRg3qsCuB62Zc3jKs8n%2BH3QHamNVJ%2BMB6t%2Fupozs5SKY2RTwrjdbSoJAidzy4UmHSDEpQNH5tl4294qvlY1x07k6plT2XPBiVW4EQMQ0OmDRIvdW54pHYlKpAK2kQPPOiCTgQt9CYAahDaFKr1ijzJJp5iD8XNF4sPXYwXOe%2FnYIlOd2h%2F8WOUHoSsZqlQqgKZCB3gFRAu9COO3eEQ6pR6ydUeQ8%2FgWfu5pZK2geWenABPLjwWB%2FwAwGB737bwWwgRjZoIds8Dfifo2Mb3GjjlskAOcYXtHYaSe6EAu2H%2Bd7K86QVCt2G0d%2BqbXRThSUVy%2BMuTd6tyOfLiszjPghjUB9duRAwURj7o9BvVtiUSnuww05DptwY6sQGiXpxW4n%2FsIOCzsSYLgOTheJW5sXaB3HAjAXSSFnlmZsU5kmYv4a35Qy0noAIGvqloIH12DZRxFgQnftPHlOnWj32kaF5zVOFlylhT%2FiyUUYBBxDdBJS3KIFJxOBCxnPl9WrdJjo9y2q4kQ8Yd2TAkUW6I7TYiQp3G%2FC%2BjjCdXYzgjWAqMoAYLF4XEpdzy29LxqrZ7KBG9RCJ9nXqDifpFHXDUiE4aSYal9FQVl2uENW8%3D&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Date=20240930T060000Z&X-Amz-SignedHeaders=host&X-Amz-Expires=21600&X-Amz-Credential=ASIAZH6WM4PL3N7LUI35%2F20240930%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Signature=0f1b27f14a23b6067bdcb73b5c8449f1fb0bc89a441901df9f4be4a4c0f7a642
//https://learn-eu-central-1-prod-fleet01-xythos.content.blackboardcdn.com/5f5880ccc4141/9585807?X-Blackboard-S3-Bucket=learn-eu-central-1-prod-fleet01-xythos&X-Blackboard-Expiration=1727697600000&X-Blackboard-Signature=JALQG23rykvp9GRhqR9kwYfa%2BxSJy%2FDjZADBu1ImOm8%3D&X-Blackboard-Client-Id=515070&X-Blackboard-S3-Region=eu-central-1&response-cache-control=private%2C%20max-age%3D21600&response-content-disposition=inline%3B%20filename%2A%3DUTF-8%27%27Chp13.pdf&response-content-type=application%2Fpdf&X-Amz-Security-Token=IQoJb3JpZ2luX2VjECcaDGV1LWNlbnRyYWwtMSJHMEUCIDZqf68ovm9YoP%2FWIs9W5p2EGEBnuZMLsKMwHewR9VeDAiEAhDTyQNoneZKsSDacPE9ujpWWHRthfP7IN4lcsCswBesqvgUIcBAEGgw2MzU1Njc5MjQxODMiDOCheVX4keAMQ3VxqCqbBfDIWHLKdLJerrXESppGrOB6VR5xRrgOpQVsMLgcBYUhdp66Yv1hoPOpJppbqRKgR6NxTSRrhJR397Wn0ObCpHlKe13sg4NVIpCWZUJzqrzJs7onuc2t3vwsdQ7ogIs8Kbq48jpgVJZMlnACw3Y01zRTFYbZMrDt%2FpOuLFGDadqtVju82Zewd9JFDj%2Ff1ZVACNAlTVAscg1BGLzfzA1wwmO8BEZUBJMFbqhnPGW%2Fj9G8V3D3GVITsrPXfJLK8gO6Th337gh%2FFKSmlvN%2BY7YInbvcBU2aW2S4W%2BIhjoYhf6pNwmo2j02ZBH7vpb4Mujq602UvyRP4Gwgft9fWETVgbjD4Spbghw8n3I%2FWeQyO3eCbllXB0JOFpL1QvIyOFCrPYJejwE8OLcmJK%2FY7O%2FI6koKooyLe9yTCxIk3NZrWbwmUpk%2BluNl4SWyZ94miDmaIf2iiRoC3uwFKg6BAjetWQWQhRC1hLhp1U3p0PHcmb5fZiQGjV9ROn3DhB%2BgtjYIXe3HqdUBQ4bib87FRg3qsCuB62Zc3jKs8n%2BH3QHamNVJ%2BMB6t%2Fupozs5SKY2RTwrjdbSoJAidzy4UmHSDEpQNH5tl4294qvlY1x07k6plT2XPBiVW4EQMQ0OmDRIvdW54pHYlKpAK2kQPPOiCTgQt9CYAahDaFKr1ijzJJp5iD8XNF4sPXYwXOe%2FnYIlOd2h%2F8WOUHoSsZqlQqgKZCB3gFRAu9COO3eEQ6pR6ydUeQ8%2FgWfu5pZK2geWenABPLjwWB%2FwAwGB737bwWwgRjZoIds8Dfifo2Mb3GjjlskAOcYXtHYaSe6EAu2H%2Bd7K86QVCt2G0d%2BqbXRThSUVy%2BMuTd6tyOfLiszjPghjUB9duRAwURj7o9BvVtiUSnuww05DptwY6sQGiXpxW4n%2FsIOCzsSYLgOTheJW5sXaB3HAjAXSSFnlmZsU5kmYv4a35Qy0noAIGvqloIH12DZRxFgQnftPHlOnWj32kaF5zVOFlylhT%2FiyUUYBBxDdBJS3KIFJxOBCxnPl9WrdJjo9y2q4kQ8Yd2TAkUW6I7TYiQp3G%2FC%2BjjCdXYzgjWAqMoAYLF4XEpdzy29LxqrZ7KBG9RCJ9nXqDifpFHXDUiE4aSYal9FQVl2uENW8%3D&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Date=20240930T060000Z&X-Amz-SignedHeaders=host&X-Amz-Expires=21600&X-Amz-Credential=ASIAZH6WM4PL3N7LUI35%2F20240930%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Signature=98e0ca8b15bf095c061fcc5676de0ff80d2f75d16313456acbb8a7ecc3b4b4cd